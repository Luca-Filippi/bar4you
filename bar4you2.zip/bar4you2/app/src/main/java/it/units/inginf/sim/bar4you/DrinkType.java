package it.units.inginf.sim.bar4you;

public enum DrinkType {
    BEER,
    WINE,
    COCKTAIL,
    SOFT_DRINK
}
